int A[MAX_VERTICES][MAX_VERTICES];

void floyd(int n)  
{ 

	int i, j, k;
	for(i=0; i<n; i++)
		for(j=0; j<n; j++)
			A[i][j]=weight[i][j];

 	for(k=0; k<n; k++)
		for(i=0; i<n; i++)
	   		for(j=0; j<n; j++)
	      		if (A[i][k]+A[k][j] < A[i][j])
	         		A[i][j] = A[i][k]+A[k][j];
}
