// graph_def.cpp : Defines the entry point for the console application.
//
#include <stdio.h>
#define MAX_VERTICES 5
//int adj_mat[MAX_VERTICES][MAX_VERTICES]={
//	{0,1,0,1},       //     0 
//	{1,0,1,1},       // +   +   +            
//	{0,1,0,1},       // 1---2---3   
//	{1,1,1,0} };     // +-------+     
int adj_mat[MAX_VERTICES][MAX_VERTICES]={
	{0,1,1,0,0},     
	{1,0,0,0,0},                
	{1,0,0,0,0},  
	{0,0,0,0,1}, 
	{0,0,0,1,0} };     
int visited[MAX_VERTICES];
int n=5;		// ���� ����� ����
int count;

// �����迭�� ǥ���� �׷����� ���� ���̿켱Ž��
void dfs_mat(int v)
{
   int w;
   visited[v] = count;
   printf("%d ", v);
   for(w=0; w<n; w++) 
 	 if( adj_mat[v][w] && !visited[w] )
	   	dfs_mat(w);
}
 
	

void main()
{
	//dfs_mat(0);
	int i;
	count=0;
	for(i=0; i<n; i++)
		if(!visited[i]){
			count++;
			dfs_mat(i);
		}
	for(i=0; i<n; i++)
		 printf("%d ", visited[i]);
}
 